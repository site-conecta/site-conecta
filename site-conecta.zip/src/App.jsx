import React from 'react';
import './App.css';
import Logo from '/Logo_CONECTA_branco_com_laranja.png';
import { FaWhatsapp } from 'react-icons/fa';

const BrandColors = () => (
  <style>{`
    :root {
      --brand-bg: #002856;
      --brand-primary: #ff6600;
      --brand-secondary: #00a3e0;
      --brand-text: #ffffff;
      --brand-muted: #cccccc;
      --brand-card: rgba(255,255,255,0.06);
      --brand-border: rgba(255,255,255,0.12);
    }
  `}</style>
);

const Header = () => (
  <header className="flex justify-between items-center p-4" style={{background: 'var(--brand-bg)'}}>
    <img src={Logo} alt="CONECTA" className="h-12" />
    <a href="https://wa.me/551151974080" target="_blank" rel="noreferrer" className="px-4 py-2 rounded-lg" style={{background: 'var(--brand-primary)', color: 'var(--brand-text)'}}>
      Assine já
    </a>
  </header>
);

const Planos = () => {
  const dados = [
    { vel: '350 Mega', preco: 'R$ 79,99' },
    { vel: '500 Mega', preco: 'R$ 89,99' },
    { vel: '700 Mega', preco: 'R$ 99,99' },
    { vel: '1 Giga', preco: 'R$ 129,99' },
  ];

  return (
    <section className="grid gap-6 p-6" style={{background: 'var(--brand-bg)', color: 'var(--brand-text)'}}>
      {dados.map((p) => (
        <div key={p.vel} className="rounded-2xl p-6 ring-1" style={{background: 'var(--brand-card)', borderColor: 'var(--brand-border)'}}>
          <h3 className="text-2xl font-bold">{p.vel}</h3>
          <p className="text-xl mt-2">{p.preco}</p>
          <a href="https://wa.me/551151974080" target="_blank" rel="noreferrer" className="mt-4 inline-block px-4 py-2 rounded-lg" style={{background: 'var(--brand-primary)', color: 'var(--brand-text)'}}>
            Assinar agora
          </a>
        </div>
      ))}
    </section>
  );
};

const WhatsAppFlutuante = () => (
  <a
    href="https://wa.me/551151974080"
    target="_blank"
    rel="noreferrer"
    className="fixed bottom-6 right-6 rounded-full p-4 shadow-2xl ring-1 hover:scale-105 transition"
    style={{background: 'var(--brand-primary)', color: '#fff', borderColor: 'var(--brand-border)'}}
    aria-label="Fale no WhatsApp"
  >
    <FaWhatsapp size={32} />
  </a>
);

export default function App() {
  return (
    <>
      <BrandColors />
      <Header />
      <Planos />
      <WhatsAppFlutuante />
    </>
  );
}
